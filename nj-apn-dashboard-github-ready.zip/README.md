# New Jersey APN Full Practice Authority Surveillance Dashboard

A public-data prototype decision-support dashboard developed for EMPH 542 at the Yale School of Public Health.

## Live dashboard
After GitHub Pages is enabled, the site will be available at:

`https://madamejones625.github.io/nj-apn-dashboard/`

## Project scope
This dashboard establishes a descriptive, pre-implementation baseline for longitudinal monitoring of New Jersey Advanced Practice Nurse (APN) Full Practice Authority. It integrates public information related to healthcare quality, structural access, social vulnerability, and provider workforce context.

The dashboard does **not** estimate causal effects of Full Practice Authority.

## Public data sources
- CMS Care Compare / Provider Data Catalog
- U.S. Census Bureau American Community Survey
- CDC/ATSDR Social Vulnerability Index
- HRSA Health Professional Shortage Areas
- NPPES (provider workforce source assessed; county linkage requires a validated crosswalk)

## Repository structure
- `index.html` — dashboard homepage
- `assets/` — extracted dashboard figures
- `.nojekyll` — ensures GitHub Pages serves the site as a plain static site

## Academic attribution
Developed by Kanesha Jones as part of graduate work in Health Informatics at the Yale School of Public Health, August 2026.

## Note
This public version separates the dashboard figures from the HTML file to improve GitHub Pages reliability and loading performance.
